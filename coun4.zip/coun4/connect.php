<html>
<head>
<title>DBIT-Counselling </title>
	<link rel="icon" href="https://upload.wikimedia.org/wikipedia/en/9/97/DBIT_logo.png" type="image/png"></link>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<style type="text/css">


		hr{
			border:0.1px solid steelblue;
		}


		header{
				background:steelblue;
			}
      .mySlides {display:none;}

		blockquote{
				margin-left:20%;
				margin-right:20%;
		    	padding: 5px;
			    background-color:steelblue;
		    	border-left: 10px solid black;
			}
		input[type=submit] {
				background-color: steelblue;
				color: white;
				padding: 5px 8px;
				margin: 4px 0;
				border: none;
				border-radius: 3px;
				cursor: pointer;
			}

			input[type=submit]:hover {
				background-color:dark blue;
			}
			fieldset{
				margin-left: 25%;
				margin-right:25%;
				display: block;
				width: 50%;
				box-shadow: 2px solid grey;

			}
			h2 , h3{
				font-family: serif;
			}
			a{
				text-decoration: none;
				color:black;
			}

      ul{
				list-style-type: none;
				margin: 2;
				padding: 2;
				overflow: hidden;
				background-color:steelblue;
				/*background:#e67e22;*/
			}


			li{
        float: left;
        border-right:1px solid #161F41;
			}
			li a{
				display: block ;
				color: white;
				text-align: right;
				padding: 10px;
				text-decoration:none;

			}
			li a:hover:not(.active){
				background-color:#161F41;
				text-decoration:none;
			}
      .active {
    background-color:#161F41 ;
      }

      li:last-child {
    border-right: none;
      }


      body {
        background-color: white ;
        background-repeat: no-repeat;
     }

     div.gallery {
    border: 1px solid #ccc;
    float: left;
}

div.gallery:hover {
    border: 1px solid #777;
}

div.gallery img {
   
}

div.desc {
    padding: 15px;
    text-align: center;
}


	</style>
</head>
<body background-color="white">
<br>
	<header>
	<table align="center">
		<tr>
			<td><img src="dbitlogo.png" alt="DBIT LOGO" style="width: 75px;height: 75px;"></td>
			<td><font size="6" color="white">DON BOSCO INSTITUTE OF TECHNOLOGY</font><br>
			    <center><font size="6" color="white">COUNSELLING DEPARTMENT</font></center>
			</td>
		</tr>
	</table>
</header>
  <hr>
  <br>

  <ul id="gp" align="center">
          <li><a href="homepage.html">Home</a></li>
	  <li><a href="#">About Us</a></li>
          <li><a href="counselfinal.html">Take a test !</a></li>
          <li><a href="info.html">Food for thought ! </a></li>
          <li><a href="contact.html">Contact Us</a></li>
          <li style="float:right"><a href="http://www.dbit.in/">Exit</a></li>
          <li style="float:right"><a href="rad1.php">Admin</a></li>
        </ul>
	<br>
<center>
<?php
$servername = "localhost";
$username = "root";
$password = "vaishali";
$dbname = "counselling";
// Create connection

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "<br>Thanks for taking the test!<br>";


$FirstName=$_POST['fname'];
$Class=$_POST['class'];
$Dept=$_POST['dept'];
$Email=$_POST['email'];
$Phone=$_POST['phone'];
$Rollno=$_POST['rollno'];
$rad1 = $_POST['one'];
$rad2 = $_POST['two'];
$rad3 = $_POST['three'];
$rad4 = $_POST['four'];
$rad5 = $_POST['five'];
$rad6 = $_POST['six'];
$rad7 = $_POST['seven'];
$rad8 = $_POST['eight'];
$rad9 = $_POST['nine'];
$rad10 =$_POST['ten'];
$rad11 =$_POST['eleven'];
$rad12 =$_POST['twelve'];
$rad13 =$_POST['thirteen'];
$rad14 =$_POST['fourteen'];
$rad15 =$_POST['fifteen'];
$rad16 =$_POST['sixteen'];
$rad17 =$_POST['seventeen'];
$rad18 =$_POST['eighteen'];
$rad19 =$_POST['nineteen'];
$rad20 =$_POST['twenty'];
$rad21 =$_POST['twentyone'];

$s_total= $rad1 + $rad6 +$rad8 + $rad11 + $rad12 + $rad14 + $rad18;
$a_total= $rad2 + $rad4 +$rad7 + $rad9 + $rad15 + $rad19 + $rad20;
$d_total= $rad3 + $rad5 +$rad10 + $rad13 + $rad16 + $rad17 + $rad21;

$total=$s_total + $a_total + $d_total;

$sql = "INSERT INTO  student_data (fname, class , dept, email, phone, rollno, one, two, three, four, five, six, seven, eight, nine, ten, eleven, twelve, thirteen, fourteen, fifteen, sixteen, seventeen, eighteen, nineteen, twenty, twentyone, stotal, atotal, dtotal)
VALUES ('$FirstName', '$Class', '$Dept', '$Email', '$Phone', '$Rollno', '$rad1','$rad2','$rad3','$rad4','$rad5','$rad6','$rad7','$rad8', '$rad9','$rad10','$rad11','$rad12','$rad13','$rad14','$rad15','$rad16','$rad17','$rad18','$rad19','$rad20','$rad21','$s_total', '$a_total', '$d_total')";

if ($conn->query($sql) === TRUE) {
    echo "<br>Your score has been recorded succesfully";
    
    // *CODE FOR DISPLAYING DIFFERENT MESSAGES TO DIFFERENT MARKS*
    if($total<15)
    {
    	echo "<br>You have mild depression";
    }
    if($total>15&&$total<50)
    {
    	echo "<br>You have moderate depression";
    }
	 if($total>50)
    {
    	echo "<br>You have severe depression";
    }

    //echo "Please meet your counsellor ---- on ------ at ------";
    //if($Dept=="IT" or $Dept=="CO" )
    {
    	echo "<br>Please meet your counsellor <br> Amrita Achrekar on:<br><br>";
    	$sql="SELECT * FROM coun_1 where id=(select max(id) from coun_1)";
    	$record=mysqli_query($conn,$sql);



    	while($slot=mysqli_fetch_assoc($record))
    	{
			echo "<tr>";
			echo "<td>".$slot['day_1']."</td>";
			echo":     ";
			echo"FROM: ";
			echo "<td>".$slot['time_11']."</td>";
			echo"  TO:   ";
			echo "<td>".$slot['time_21']."</td><br>";
			

			echo "<td>".$slot['day_2']."</td>";
			echo":     ";
			echo"FROM: ";
			echo "<td>".$slot['time_12']."</td>";
			echo"  TO:   ";
			echo "<td>".$slot['time_22']."</td><br>";


			echo "<td>".$slot['day_3']."</td>";
			echo":     ";
			echo"FROM: ";
			echo "<td>".$slot['time_13']."</td>";
			echo"  TO:   ";
			echo "<td>".$slot['time_23']."</td><br>";

			echo "</tr>";
		}
			
    }
    echo "Take prior appointment via phone or email.<br>Phone number:1234567<br>email:vaishali@dbit.in";
   
   // else
   {
		echo "<br><br>OR";
    	echo "<br>Kshitija Sawant on <br><br>";
    	$sql="SELECT * FROM coun_2 where id=(select max(id) from coun_2)";
    	$record=mysqli_query($conn,$sql);
    	while($slot=mysqli_fetch_assoc($record))
    	{
			echo "<tr>";
			echo "<td>".$slot['day_1']."</td>";
			echo":     ";
			echo"FROM: ";
			echo "<td>".$slot['time_11']."</td>";
			echo"  TO:   ";
			echo "<td>".$slot['time_21']."</td><br>";
			

			echo "<td>".$slot['day_2']."</td>";
			echo":     ";
			echo"FROM: ";
			echo "<td>".$slot['time_12']."</td>";
			echo"  TO:   ";
			echo "<td>".$slot['time_22']."</td><br>";


			echo "<td>".$slot['day_3']."</td>";
			echo":     ";
			echo"FROM: ";
			echo "<td>".$slot['time_13']."</td>";
			echo"  TO:   ";
			echo "<td>".$slot['time_23']."</td><br>";

			echo "</tr>";
		}
		echo "Take prior appointment via phone or email.<br>Phone number:1234567<br>email:vaishali@dbit.in";	
    }

    
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}







$conn->close();


echo"</table>";
?>
</center>
</body>
</html>
