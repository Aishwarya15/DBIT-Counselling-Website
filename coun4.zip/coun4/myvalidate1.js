function myFunction() {

 

 var a = document.forms["counselfinal"]["fname"];

if (a.value == "") {
        alert("Please enter your name.");
        return false;
}

 var b = document.forms["counselfinal"]["class"];

if (b.value == "select-class") {
        alert("Please select your class.");
        return false;
}

 var c = document.forms["counselfinal"]["dept"];

if (c.value == "I") {
        alert("Please select your department.");
        return false;
}

 var d = document.forms["counselfinal"]["email"];

if (d.value == "") {
        alert("Please enter a valid email id.");
        return false;
}

 var e = document.forms["counselfinal"]["phone"];

if (e.value == "") {
        alert("Please enter your contact number.");
        return false;
}

var f = document.forms["counselfinal"]["rollno"];

if (f.value == "") {
        alert("Please enter your roll number.");
        return false;
}

var a1 = document.forms["counselfinal"]["one"];

if (a1.value == "") {
        alert("Question 1 is not answered.All questions are compusory.");
        return false;
}

var a2 = document.forms["counselfinal"]["two"];

if (a2.value == "") {
        alert("Question 2 is not answered.All questions are compusory.");
        return false;
}

var a3 = document.forms["counselfinal"]["three"];

if (a3.value == "") {
        alert("Question 3 is not answered.All questions are compusory.");
        return false;
}

var a4 = document.forms["counselfinal"]["four"];

if (a4.value == "") {
        alert("Question 4 is not answered.All questions are compusory.");
        return false;
}

var a5 = document.forms["counselfinal"]["five"];

if (a5.value == "") {
        alert("Question 5 is not answered.All questions are compusory.");
        return false;
}

var a6 = document.forms["counselfinal"]["six"];

if (a6.value == "") {
        alert("Question 6 is not answered.All questions are compusory.");
        return false;
}

var a7 = document.forms["counselfinal"]["seven"];

if (a7.value == "") {
        alert("Question 7 is not answered.All questions are compusory.");
        return false;
}

var a8 = document.forms["counselfinal"]["eight"];

if (a8.value == "") {
        alert("Question 8 is not answered.All questions are compusory.");
        return false;
}

var a9 = document.forms["counselfinal"]["nine"];

if (a9.value == "") {
        alert("Question 9 is not answered.All questions are compusory.");
        return false;
}

var a10 = document.forms["counselfinal"]["ten"];

if (a10.value == "") {
        alert("Question 10 is not answered.All questions are compusory.");
        return false;
}

var a11 = document.forms["counselfinal"]["eleven"];

if (a11.value == "") {
        alert("Question 11 is not answered.All questions are compusory.");
        return false;
}

var a12 = document.forms["counselfinal"]["twelve"];

if (a12.value == "") {
        alert("Question 12 is not answered.All questions are compusory.");
        return false;
}

var a13 = document.forms["counselfinal"]["thirteen"];

if (a13.value == "") {
        alert("Question 13 is not answered.All questions are compusory.");
        return false;
}

var a14 = document.forms["counselfinal"]["fourteen"];

if (a14.value == "") {
        alert("Question 14 is not answered.All questions are compusory.");
        return false;
}

var a15 = document.forms["counselfinal"]["fifteen"];

if (a15.value == "") {
        alert("Question 15 is not answered.All questions are compusory.");
        return false;
}

var a16 = document.forms["counselfinal"]["sixteen"];

if (a16.value == "") {
        alert("Question 16 is not answered.All questions are compusory.");
        return false;
}

var a17 = document.forms["counselfinal"]["seventeen"];

if (a17.value == "") {
        alert("Question 17 is not answered.All questions are compusory.");
        return false;
}

var a18 = document.forms["counselfinal"]["eighteen"];

if (a18.value == "") {
        alert("Question 18 is not answered.All questions are compusory.");
        return false;
}

var a19 = document.forms["counselfinal"]["nineteen"];

if (a19.value == "") {
        alert("Question 19 is not answered.All questions are compusory.");
        return false;
}

var a20 = document.forms["counselfinal"]["twenty"];

if (a20.value == "") {
        alert("Question 20 is not answered.All questions are compusory.");
        return false;
}

var a21 = document.forms["counselfinal"]["twentyone"];

if (a21.value == "") {
        alert("Question 21 is not answered.All questions are compusory.");
        return false;
}




}